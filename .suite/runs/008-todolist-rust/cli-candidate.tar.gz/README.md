# TODO CLI

Build with a Rust toolchain from this directory:

```sh
cargo build --locked
cargo run -- add "Buy milk"
cargo run -- list
cargo run -- complete 1
cargo run -- delete 1
cargo run -- help
```

The built binary is `target/debug/todolist`. It also accepts `--help` or no
arguments for usage. Quote descriptions containing spaces; IDs are positive
integers. Invalid commands or failed operations print an error to stderr and
return a nonzero exit status.

Tasks persist in `tasks.json` in this application directory, resolved at build
time independently of the directory from which the binary is invoked. The file
is created on the first data operation. Descriptions are trimmed and must not be
blank. Deleted tasks disappear from listings, and their IDs are not reused.

`list` emits a tab-separated `id`, `status`, `description` header and active rows
ordered by ID. Status is `New` or `Completed`. Backslashes, tabs, carriage returns,
and newlines in descriptions display as `\\`, `\t`, `\r`, and `\n` so each task
occupies one row. Mutations print a confirmation containing the task ID.

The JSON store supports one writer at a time; concurrent writers require
external coordination.
