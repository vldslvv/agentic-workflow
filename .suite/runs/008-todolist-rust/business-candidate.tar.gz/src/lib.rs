//! Persistent TODO operations shared by application entry points.

use serde::{Deserialize, Serialize};
use std::fs;
use std::io::{self, Write};
use std::path::{Path, PathBuf};

pub type Result<T> = std::result::Result<T, Box<dyn std::error::Error>>;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum Status {
    New,
    Completed,
    Deleted,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct Task {
    pub id: i32,
    pub description: String,
    pub status: Status,
}

#[derive(Serialize, Deserialize)]
struct Data {
    next_id: i32,
    tasks: Vec<Task>,
}

/// A JSON task store. Each operation reloads the file before reading or changing it.
/// Concurrent writers require external coordination.
pub struct Store {
    path: PathBuf,
}

impl Store {
    /// Resolve application data independently of the caller's working directory.
    pub fn default_path() -> PathBuf {
        Path::new(env!("CARGO_MANIFEST_DIR")).join("tasks.json")
    }

    pub fn open(path: impl AsRef<Path>) -> Result<Self> {
        let store = Self {
            path: path.as_ref().to_path_buf(),
        };
        match fs::read(&store.path) {
            Ok(bytes) => {
                Self::decode(&bytes)?;
            }
            Err(error) if error.kind() == io::ErrorKind::NotFound => {
                store.save(&Data {
                    next_id: 1,
                    tasks: Vec::new(),
                })?;
            }
            Err(error) => return Err(error.into()),
        }
        Ok(store)
    }

    pub fn add(&mut self, description: &str) -> Result<Task> {
        let description = description.trim();
        if description.is_empty() {
            return Err("task description must not be blank".into());
        }
        let mut data = self.load()?;
        let task = Task {
            id: data.next_id,
            description: description.to_owned(),
            status: Status::New,
        };
        data.next_id = data.next_id.checked_add(1).ok_or("task IDs exhausted")?;
        data.tasks.push(task.clone());
        self.save(&data)?;
        Ok(task)
    }

    pub fn list(&self) -> Result<Vec<Task>> {
        let mut tasks = self.load()?.tasks;
        tasks.retain(|task| task.status != Status::Deleted);
        tasks.sort_by_key(|task| task.id);
        Ok(tasks)
    }

    pub fn complete(&mut self, id: i32) -> Result<()> {
        self.set_status(id, Status::Completed)
    }

    pub fn delete(&mut self, id: i32) -> Result<()> {
        self.set_status(id, Status::Deleted)
    }

    fn set_status(&self, id: i32, status: Status) -> Result<()> {
        let mut data = self.load()?;
        let task = data
            .tasks
            .iter_mut()
            .find(|task| task.id == id && task.status != Status::Deleted)
            .ok_or_else(|| format!("task {id} not found"))?;
        if task.status != status {
            task.status = status;
            self.save(&data)?;
        }
        Ok(())
    }

    fn load(&self) -> Result<Data> {
        Self::decode(&fs::read(&self.path)?)
    }

    fn decode(bytes: &[u8]) -> Result<Data> {
        let data: Data = serde_json::from_slice(bytes)?;
        let mut ids = std::collections::HashSet::new();
        if data.next_id <= 0
            || data.tasks.iter().any(|task| {
                task.id <= 0
                    || task.id >= data.next_id
                    || !ids.insert(task.id)
                    || task.description.trim().is_empty()
            })
        {
            return Err("invalid task store: IDs or descriptions are inconsistent".into());
        }
        Ok(data)
    }

    fn save(&self, data: &Data) -> Result<()> {
        let parent = self
            .path
            .parent()
            .filter(|path| !path.as_os_str().is_empty())
            .unwrap_or_else(|| Path::new("."));
        let mut temporary = tempfile::NamedTempFile::new_in(parent)?;
        serde_json::to_writer_pretty(&mut temporary, data)?;
        temporary.write_all(b"\n")?;
        temporary.as_file().sync_all()?;
        temporary.persist(&self.path)?;
        Ok(())
    }
}
